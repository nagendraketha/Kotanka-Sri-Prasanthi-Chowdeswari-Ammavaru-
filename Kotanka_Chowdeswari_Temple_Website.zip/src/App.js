
import React from "react";
import "./App.css";

const templeImages = [
  "/temple1.jpg", "/temple2.jpg", "/temple3.jpg", "/temple4.jpg", "/temple5.jpg",
  "/temple6.jpg", "/temple7.jpg", "/temple8.jpg", "/temple9.jpg", "/temple10.jpg"
];

function App() {
  return (
    <div style={{ padding: "1rem", fontFamily: "sans-serif" }}>
      <h1 style={{ textAlign: "center", color: "#b91c1c" }}>
        Kotanka Sri Prashanthi Chowdeswari Ammavaru ఆలయం
      </h1>
      <p style={{ textAlign: "center" }}>కొటంక గ్రామం, గర్లదిన్నె మండలం, అనంతపురం జిల్లా</p>

      <h2>ఆలయ చరిత్ర</h2>
      <p>
        రాక్షసులను సంహరించుటకై ఆదిశక్తి యోగమాయచే విష్ణవంశమున మహిషాసురునకు కుమార్తెగా జన్మించినది.
        పితృగండమున ఉద్బవించుటచే ఆమె ఒక శిలామందసమున బంధించి భూస్థాపితము చేసిరి...
      </p>

      <h2>ఆలయ చిత్రాలు</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(150px, 1fr))", gap: "10px" }}>
        {templeImages.map((src, idx) => (
          <img key={idx} src={src} alt={`Temple ${idx + 1}`} style={{ width: "100%", borderRadius: "8px" }} />
        ))}
      </div>

      <h2>ఆలయ స్థానం</h2>
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3872.4790308506187!2d77.6439831!3d14.7920517!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bb1516e27e8cfbf%3A0xe11975587e4a5276!2sKotanka%2C%20Andhra%20Pradesh%20515004!5e0!3m2!1sen!2sin!4v1718066940000!5m2!1sen!2sin"
        width="100%"
        height="300"
        style={{ border: 0 }}
        allowFullScreen=""
        loading="lazy"
        title="Temple Location"
      ></iframe>
    </div>
  );
}

export default App;
